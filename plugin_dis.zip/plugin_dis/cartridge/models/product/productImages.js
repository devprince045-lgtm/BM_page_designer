'use strict';

/**
 * @constructor
 * @classdesc Returns images for a given product
 * @param {dw.catalog.Product} product - product to return images for
 * @param {Object} imageConfig - configuration object with image types
 */
function Images(product, imageConfig) {
    var collections = require('*/cartridge/scripts/util/collections');
    var ProductImageDIS = require('*/cartridge/scripts/helpers/ProductImageDIS');

    imageConfig.types.forEach(function (type) {
        var result = {};

        if (imageConfig.quantity === 'single') {
            var firstImage = new ProductImageDIS(product, type);

            if (firstImage && !empty(product)) {
                var imageTag = firstImage.generateImageModel({ urlFn: imageConfig.urlFn });

                result = [imageTag];
            } else {
                var URLUtils = require('dw/web/URLUtils');
                result = [{
                    alt: 'No Image',
                    index: 0,
                    title: 'No Image',
                    url: URLUtils.staticURL('/images/noimagelarge.png').https().toString()
                }];
            }
        } else {
            var images = ProductImageDIS.getImages(product, type);
            result = collections.map(images, function (image, index) {
                return image.generateImageModel({
                    index: index,
                    urlFn: imageConfig.urlFn
                });
            });
        }
        this[type] = result;
    }, this);
}

module.exports = Images;
