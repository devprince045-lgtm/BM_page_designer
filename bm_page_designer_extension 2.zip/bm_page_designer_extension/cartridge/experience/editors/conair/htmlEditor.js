'use strict';

var HashMap = require('dw/util/HashMap');
var PageMgr = require('dw/experience/PageMgr');

module.exports.init = function (editor) {
    var breakoutEditorConfig = new HashMap();
    var breakoutEditor = PageMgr.getCustomEditor('conair.htmlEditorBreakout', breakoutEditorConfig);
    editor.dependencies.put('htmlEditor_Breakout', breakoutEditor);
};
