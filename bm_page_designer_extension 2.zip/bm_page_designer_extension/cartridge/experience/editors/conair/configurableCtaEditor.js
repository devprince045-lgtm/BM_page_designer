'use strict';

/**
 * Configurable CTA Editor UI component
 */
module.exports.init = function () {
};
