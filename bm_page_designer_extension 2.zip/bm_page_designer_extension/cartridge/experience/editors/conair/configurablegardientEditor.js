'use strict';

/**
 * Configurable Gardient Editor UI component
 */
module.exports.init = function () {
};
