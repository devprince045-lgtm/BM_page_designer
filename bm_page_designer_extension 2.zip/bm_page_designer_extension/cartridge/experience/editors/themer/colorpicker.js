
'use strict';

var HashMap = require('dw/util/HashMap');

/** creating a color picker
 *
 * @param {Object} editor set the color picker
 */
module.exports.init = function (editor) {
    var siteId = require('dw/system/Site').getCurrent().ID;
    var preferences = require('../../../config/preferences');

    const defaultFallbackColors = [
        '#e3abec', '#c2dbf7', '#9fd6ff', '#9de7da', '#9df0c0', '#fff099', '#fed49a',
        '#d073e0', '#86baf3', '#5ebbff', '#44d8be', '#3be282', '#ffe654', '#ffb758',
        '#bd35bd', '#5779c1', '#00a1e0', '#00aea9', '#3cba4c', '#f5bc25', '#f99221',
        '#580d8c', '#001970', '#0a2399', '#0b7477', '#41693d', '#b67e11', '#b85d0d',
        '#FFFFFF', '#DDDDDD', '#BBBBBB', '#999999', '#666666', '#333333', '#000000'
    ];
    const currentSiteColors = preferences.colorsArray[siteId] || preferences.colorsArray.default || defaultFallbackColors;
    if (!editor.configuration) {
        editor.configuration = new HashMap();
    }

    editor.configuration.put('colorsArray', currentSiteColors);
};
