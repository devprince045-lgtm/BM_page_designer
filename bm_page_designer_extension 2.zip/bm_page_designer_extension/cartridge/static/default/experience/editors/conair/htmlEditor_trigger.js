(() => {
    let inputEl;
    let buttonEl;

    subscribe('sfcc:ready', async ({ value }) => {
        // Initialize the DOM
        const template = obtainTemplate();
        const clone = document.importNode(template.content, true);
        document.body.appendChild(clone);

        // Obtain DOM elements and apply event handlers
        inputEl = document.querySelector('input');
        buttonEl = document.querySelector('button');
        buttonEl.addEventListener('click', handleBreakoutOpen);

        // Update <input> value
        inputEl.value = obtainDisplayValue(value);
    });

    function obtainTemplate() {
        const template = document.createElement('template');
        template.innerHTML = `
  <div class="slds-grid">
    <div class="slds-col slds-grow">
      <input type="hidden" disabled class="slds-input" placeholder="HTML Section Editor">
    </div>
    <div class="slds-col slds-grow-none" style="width: 100%;">
      <button type="button" class="slds-button slds-button_neutral" style="width: 100%;">Open HTML Editor</button>
    </div>
  </div>`;
        return template;
    }

    function obtainDisplayValue(value) {
        return typeof value === 'object' && value != null && typeof value.value === 'string' ? value.value : null;
    }

    function handleBreakoutOpen() {
        emit({
            type: 'sfcc:breakout',
            payload: {
                id: 'htmlEditor_Breakout',
                title: 'Page Designer HTML Editor'
            }
        }, handleBreakoutClose);
    }

    function handleBreakoutClose({ type, value }) {
        if (type === 'sfcc:breakoutApply') {
            handleBreakoutApply(value);
        } else {
            handleBreakoutCancel();
        }
    }

    function handleBreakoutCancel() {
        // Grab focus
        buttonEl && buttonEl.focus();
    }

    function handleBreakoutApply(value) {
        // Update <input> value
        inputEl.value = obtainDisplayValue(value);

        // Emit value update to Page Designer
        emit({
            type: 'sfcc:value',
            payload: value
        });

        // Grab focus
        buttonEl && buttonEl.focus();
    }
})();
