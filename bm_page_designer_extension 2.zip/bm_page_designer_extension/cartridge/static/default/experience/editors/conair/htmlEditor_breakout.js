(() => {
    let gridEl;

    function updateCVPreview(forceUpdatePreview, data) {
        var preview = document.getElementById("preview");
        preview.innerHTML = data;

        if (forceUpdatePreview){
            var scripts = preview.getElementsByTagName('script');
            for (var i = 0; i < scripts.length; i++) {
                var script = document.createElement('script');
                script.text = scripts[i].innerHTML;
                document.head.appendChild(script);
            }
        };
    };

    subscribe('sfcc:ready', async ({ value, }) => {
        var placeholder = value && value.value ? value.value : '';
        // Initialize the DOM
        const template = obtainTemplate();
        const clone = document.importNode(template.content, true);
        document.body.appendChild(clone);

        // Init and append unicorn DOM
        gridEl = document.querySelector('.slds-grid');
        const itemBodyTemplate = obtainBodyTemplate(placeholder);
        const itemBodyEl = document.importNode(itemBodyTemplate.content, true);
        gridEl.appendChild(itemBodyEl);
        // placeholder preview
        updateCVPreview(false, placeholder);

        var textInput = document.getElementById('pd-html-editor');
        document.getElementById('forceUpdatePreview').addEventListener('click',function() {
            updateCVPreview(true, textInput.value);
        });

        textInput.addEventListener('change', function() {
            console.log(textInput.value);
            updateCVPreview(false, textInput.value);
            emit({
                type: 'sfcc:value',
                payload: {
                    value: textInput.value ? textInput.value : value
                }
            });
        });
    });

    function obtainTemplate() {
        const template = document.createElement('template');
        template.innerHTML = `
  <div class="slds-grid slds-grid_vertical"></div>`.trim();
        return template;
    };

    function obtainBodyTemplate(value) {
        const template = document.createElement('template');
        template.innerHTML = `
        <div role="main" id="maincontent">
        <div id="root">
            <section class="main slds-p-around_large">
                <div class="slds-grid slds-gutters slds-card" style="display: block;">
                    <div class="slds-card__header slds-grid slds-border_bottom slds-p-bottom_small">
                        <header class="slds-media slds-media_center ">
                            <div class="slds-media__figure">
                                <span class="slds-icon_container slds-icon-standard-account">
                                <svg xmlns="http://www.w3.org/2000/svg" height="20" width="20" viewBox="0 0 1000 1000" fill="#fff"><path d="M738 200H262c-34 0-62 28-62 62v476c0 34 28 62 62 62h476c34 0 62-28 62-62V262c0-34-28-62-62-62zm-455 62h434c11 0 21 9 21 21v39H262v-39c0-12 9-21 21-21zm434 476H283c-11 0-21-9-21-21V382h476v335c0 12-9 21-21 21zM467 633l-66-66 66-66c4-4 4-10 0-14l-28-28c-4-4-10-4-14 0l-73 73-15 15-13 13c-2 2-3 5-3 7 0 3 1 5 3 7l102 102c4 4 10 4 14 0l28-28c3-5 3-11-1-15zm210-74-13-13-15-15-73-73c-4-4-10-4-14 0l-28 28c-4 4-4 10 0 14l66 66-66 66c-4 4-4 10 0 14l28 28c4 4 10 4 14 0l102-102c2-2 3-5 3-7z"/></svg>
                                </span>
                            </div>
                            <div class="slds-media__body">
                                <h2 class="slds-card__header-title">Page Designer HTML Editor</h2>
                            </div>
                        </header>
                    </div>
                    <div class="slds-card__body slds-card__body_inner">
                        <div class="slds-grid slds-gutters">
                            <div class="slds-col slds-size_2-of-4">
                                <section class="slds-card slds-card_boundary" style="height: 100%;">
                                    <div class="slds-card__header slds-grid slds-border_bottom slds-p-bottom_small">
                                        <header class="slds-media slds-media_center ">
                                            <div class="slds-media__figure">
                                                <span class="slds-icon_container slds-icon-standard-account">
                                                <svg xmlns="http://www.w3.org/2000/svg" height="20" width="20" viewBox="0 0 1000 1000" fill="#fff"><path d="M738 200H262c-34 0-62 28-62 62v476c0 34 28 62 62 62h476c34 0 62-28 62-62V262c0-34-28-62-62-62zm-455 62h434c11 0 21 9 21 21v39H262v-39c0-12 9-21 21-21zm434 476H283c-11 0-21-9-21-21V382h476v335c0 12-9 21-21 21zM467 633l-66-66 66-66c4-4 4-10 0-14l-28-28c-4-4-10-4-14 0l-73 73-15 15-13 13c-2 2-3 5-3 7 0 3 1 5 3 7l102 102c4 4 10 4 14 0l28-28c3-5 3-11-1-15zm210-74-13-13-15-15-73-73c-4-4-10-4-14 0l-28 28c-4 4-4 10 0 14l66 66-66 66c-4 4-4 10 0 14l28 28c4 4 10 4 14 0l102-102c2-2 3-5 3-7z"/></svg>
                                                </span>
                                            </div>
                                            <div class="slds-media__body slds-card__header-title">HTML</div>
                                            <button id="forceUpdatePreview" class="slds-m-left_large slds-button slds-button_brand"> Update Script's</button>
                                        </header>
                                    </div>
                                    <div class="slds-card__body slds-card__body_inner">
                                        <div class="slds-illustration slds-illustration_small">
                                            <div class="slds-text-longform">
                                                <div id="editor">
                                                    <textarea id="pd-html-editor" name="html-editor" style="
                                                    height: 100%;
                                                    width: 100%;
                                                ">${value}</textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <footer class="slds-card__footer"></footer>
                                </section>
                            </div>
                            <div class="slds-col slds-size_2-of-4">
                            <section class="slds-card slds-card_boundary" style="height: 100%;">
                                <div class="slds-card__header slds-grid slds-border_bottom slds-p-bottom_small">
                                    <header class="slds-media slds-media_center ">
                                        <div class="slds-media__figure">
                                            <span class="slds-icon_container slds-icon-standard-account">
                                            <svg xmlns="http://www.w3.org/2000/svg" height="20" width="20" viewBox="0 0 1000 1000" fill="#fff"><path d="M727 206H273a30 30 0 0 0-30 30v155h514V237a30 30 0 0 0-30-31ZM455 423v371h272a30 30 0 0 0 30-30V422H456Zm-212 0v340a30 30 0 0 0 30 31h152V423H243Z"/></svg>
                                            </span>
                                        </div>
                                        <div class="slds-media__body slds-card__header-title">Preview</div>
                                    </header>
                                </div>
                                <div class="slds-card__body slds-card__body_inner">
                                    <div id="preview">
                                        <!-- inner html will be updated by the editor -->
                                    </div>
                                </div>
                                <footer class="slds-card__footer"></footer>
                            </section>
                        </div>
                        </div>
                    </div>
                    <footer class="slds-card__footer"></footer>
                </div>
            </section>
        </div>
    </div>`.trim();
        return template;
    }
})();