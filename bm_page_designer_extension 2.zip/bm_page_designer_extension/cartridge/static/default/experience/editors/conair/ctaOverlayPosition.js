
/**
 * SLDS Configurable CTA Editor
 */
(() => {

  /** The main Editor element to be tinkered with */
  var rootEditorElement;

  /** Variable that we are using to collect multiple data */
  var jsonData = {};

  /**
   * map the desktop positions of the component
   */
  const desktopComponentPosition = {
    Top: 'align-items-lg-start',
    Center: 'align-items-lg-center',
    Bottom: 'align-items-lg-end',
    Left: 'align-items-lg-start',
    Right: 'align-items-lg-end'
  };

  /**
   * map the mobile positions of the component
   */
  const mobileComponentPosition = {
    Top: 'align-items-start',
    Center: 'align-items-center',
    Bottom: 'align-items-end',
    Left: 'align-items-start',
    Right: 'align-items-end'
  };

  /**
   * initializes the base markup before page is ready. This is not part of the API, and called explicitely at the end of this module.
   */
  function init(value) {
    rootEditorElement = document.createElement('div');
    rootEditorElement.innerHTML = `
    <div class="slds-p-around_small">
    <label class="slds-form-element__label"><strong>Desktop</strong></label>
    <div class="slds-form-element slds-grid slds-gutters slds-m-bottom_medium">
      <div class="slds-col">
        <label class="slds-form-element__label" for="desktop-component-x-position">Y Position</label>
        <div class="slds-form-element__control">
          <div class="slds-select_container">
            <select class="slds-select" id="desktop-component-x-position" value="${value.desktopComponentXPosition}">
              <option value="" disabled selected>Select</option>
              <option>Top</option>
              <option>Center</option>
              <option>Bottom</option>
            </select>
          </div>
        </div>
      </div>
      <div class="slds-col">
        <label class="slds-form-element__label" for="desktop-component-y-position">X Position</label>
        <div class="slds-form-element__control">
          <div class="slds-select_container">
            <select class="slds-select" id="desktop-component-y-position" value="${value.desktopComponentYPosition}">
              <option value="" disabled selected>Select</option>
              <option>Left</option>
              <option>Center</option>
              <option>Right</option>
            </select>
          </div>
        </div>
      </div>
    </div>
    <label class="slds-form-element__label"><strong>Tablet/Mobile</strong></label>
    <div class="slds-form-element slds-grid slds-gutters">
      <div class="slds-col">
        <label class="slds-form-element__label" for="mobile-component-x-position">Y Position</label>
        <div class="slds-form-element__control">
          <div class="slds-select_container">
            <select class="slds-select" id="mobile-component-x-position" value="${value.mobileComponentXPosition}">
              <option value="" disabled selected>Select</option>
              <option>Top</option>
              <option>Center</option>
              <option>Bottom</option>
            </select>
          </div>
        </div>
      </div>
    <div class="slds-col">
      <label class="slds-form-element__label" for="mobile-component-y-position">X Position</label>
      <div class="slds-form-element__control">
        <div class="slds-select_container">
          <select class="slds-select" id="mobile-component-y-position" value="${value.mobileComponentYPosition}">
            <option value="" disabled selected>Select</option>
            <option>Left</option>
            <option>Center</option>
            <option>Right</option>
          </select>
        </div>
      </div>
    </div>
    </div>
    <input type="hidden" id="hidden-input" />
  </div>`;

    // show "Loading.. "
    document.body.appendChild(rootEditorElement);
  };

  /** the page designer signals readiness to show this editor and provides an optionally pre selected value */
  listen('sfcc:ready',async ({ value,config,isDisabled,isRequired,dataLocale,displayLocale }) => {
    const selectedValue = typeof value === 'object' && value !== null && typeof value.value === 'string' ? value.value : null;
    if (selectedValue) {
      init(value.value ? JSON.parse(value.value) : '');
      jsonData = JSON.parse(value.value);
    } else {
      init({
        desktopComponentXPosition: 'Bottom',
        mobileComponentXPosition: 'Bottom',
        desktopComponentYPosition: 'Left',
        mobileComponentYPosition: 'Left',
        desktopComponentXPositionValue: 'align-items-lg-end',
        mobileComponentXPositionValue: 'align-items-end',
        desktopComponentYPositionValue: 'align-items-lg-start',
        mobileComponentYPositionValue: 'align-items-start'
      });
    }

    var jsonElement = rootEditorElement.querySelector('#hidden-input');
    rootEditorElement.querySelector('#desktop-component-x-position').addEventListener('change',function (event) {
      const selectedValue = event.target.value;
      jsonData['desktopComponentXPosition'] = selectedValue;
      jsonData['desktopComponentXPositionValue'] = desktopComponentPosition[selectedValue];
      jsonElement.value = JSON.stringify(jsonData);
      jsonElement.dispatchEvent(new Event('change'));
    });
    rootEditorElement.querySelector('#mobile-component-x-position').addEventListener('change',function (event) {
      const selectedValue = event.target.value;
      jsonData['mobileComponentXPosition'] = selectedValue;
      jsonData['mobileComponentXPositionValue'] = mobileComponentPosition[selectedValue];
      jsonElement.value = JSON.stringify(jsonData);
      jsonElement.dispatchEvent(new Event('change'));
    });
    rootEditorElement.querySelector('#desktop-component-y-position').addEventListener('change',function (event) {
      const selectedValue = event.target.value;
      jsonData['desktopComponentYPosition'] = selectedValue;
      jsonData['desktopComponentYPositionValue'] = desktopComponentPosition[selectedValue];
      jsonElement.value = JSON.stringify(jsonData);
      jsonElement.dispatchEvent(new Event('change'));

    });
    rootEditorElement.querySelector('#mobile-component-y-position').addEventListener('change',function (event) {
      const selectedValue = event.target.value;
      jsonData['mobileComponentYPosition'] = selectedValue;
      jsonData['mobileComponentYPositionValue'] = mobileComponentPosition[selectedValue];
      jsonElement.value = JSON.stringify(jsonData);
      jsonElement.dispatchEvent(new Event('change'));

    });

    if (selectedValue) {
      const values = JSON.parse(selectedValue);
      if (values.desktopComponentXPosition != '') {
        rootEditorElement.querySelector('#desktop-component-x-position').value = values.desktopComponentXPosition;
        rootEditorElement.querySelector('#desktop-component-x-position').dispatchEvent(new Event('change'));
      }
      if (values.mobileComponentXPosition != '') {
        rootEditorElement.querySelector('#mobile-component-x-position').value = values.mobileComponentXPosition;
        rootEditorElement.querySelector('#mobile-component-x-position').dispatchEvent(new Event('change'));
      }
      if (values.desktopComponentYPosition != '') {
        rootEditorElement.querySelector('#desktop-component-y-position').value = values.desktopComponentYPosition;
        rootEditorElement.querySelector('#desktop-component-y-position').dispatchEvent(new Event('change'));
      }
      if (values.mobileComponentYPosition != '') {
        rootEditorElement.querySelector('#mobile-component-y-position').value = values.mobileComponentYPosition;
        rootEditorElement.querySelector('#mobile-component-y-position').dispatchEvent(new Event('change'));
      }
    }

    jsonElement.addEventListener('change',function (event) {
      var selectedValue = event.target.value;
      emit({
        type: 'sfcc:interacted'
      });
      emit({
        type: 'sfcc:value',
        payload: selectedValue ? { value: selectedValue } : null
      });
    });
  });

  // When a value was selected
  listen('sfcc:value',value => {
  });

  // When the editor must require the user to select something
  listen('sfcc:required',value => { });

  // When the editor is asked to disable its controls
  listen('sfcc:disabled',value => { });

})();
