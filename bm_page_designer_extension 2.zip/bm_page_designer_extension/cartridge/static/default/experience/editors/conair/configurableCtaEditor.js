/**
 * SLDS Configurable CTA Editor
 */
(() => {
	/** The main Editor element to be tinkered with */
	var rootEditorElement;

	/** Variable that we are using to collect multiple data */
	var jsonData = {};

	/**
	 * initializes the base markup before page is ready. This is not part of the API, and called explicitely at the end of this module.
	 */
	function init(value) {
		rootEditorElement = document.createElement("div");
		rootEditorElement.innerHTML = `
		<div class="slds-p-around_small">
		<div class="slds-form-element slds-grid slds-gutters">
		  <div class="slds-col">
			<label class="slds-form-element__label">Heading Style</label>
			<div class="slds-form-element__control">
			  <div class="slds-select_container">
				<select class="slds-select" id="heading-style" value="${value.headingStyle}">
				  <option value="" disabled selected>Select…</option>
				  <option>Heading 1</option>
				  <option>Heading 2 Banner</option>
				  <option>Heading 2</option>
				  <option>Heading 3 Banner</option>
				  <option>Heading 3</option>
				  <option>Heading 4</option>
				  <option>Heading 5</option>
				  <option>Heading 6</option>
				  <option>Subtitle 1</option>
				  <option>Subtitle 2</option>
				  <option>Subtitle 3</option>
				  <option>Subtitle 4</option>
				  <option>Subtitle 5</option>
				  <option>Subtitle 6</option>
				  <option>Paragraph 1</option>
				  <option>Paragraph 2</option>
				  <option>Paragraph 3</option>
				  <option>Paragraph 4</option>
				  <option>Paragraph 5</option>
				  <option>Paragraph 6</option>
				  <option>Body Bold</option>
				  <option>Body Text</option>
				  <option>Small Text / Caption</option>
				  <option>Small Text / Caption Bold</option>
				  <option>Default</option>
				</select>
			  </div>
			</div>
		  </div>
		  <div class="slds-col">
			<label class="slds-form-element__label">Description Style</label>
			<div class="slds-form-element__control">
			  <div class="slds-select_container">
				<select class="slds-select" id="description-style" value="${value.descriptionStyle}">
				  <option value="" disabled selected>Select…</option>
				  <option>Heading 1</option>
				  <option>Heading 2 Banner</option>
				  <option>Heading 2</option>
				  <option>Heading 3 Banner</option>
				  <option>Heading 3</option>
				  <option>Heading 4</option>
				  <option>Heading 5</option>
				  <option>Heading 6</option>
				  <option>Subtitle 1</option>
				  <option>Subtitle 2</option>
				  <option>Subtitle 3</option>
				  <option>Subtitle 4</option>
				  <option>Subtitle 5</option>
				  <option>Subtitle 6</option>
				  <option>Paragraph 1</option>
				  <option>Paragraph 2</option>
				  <option>Paragraph 3</option>
				  <option>Paragraph 4</option>
				  <option>Paragraph 5</option>
				  <option>Paragraph 6</option>
				  <option>Body Bold</option>
				  <option>Body Text</option>
				  <option>Small Text / Caption</option>
				  <option>Small Text / Caption Bold</option>
				  <option>Default</option>
				</select>
			  </div>
			</div>
		  </div>
		</div>
		<div class="slds-form-element slds-grid slds-gutters">
		  <div class="slds-col">
			<label class="slds-form-element__label">CTA Style</label>
			<div class="slds-form-element__control">
			  <div class="slds-select_container">
				<select class="slds-select" id="cta-style" value="${value.ctaStyle}">
				  <option value="" disabled selected>Select…</option>
				  <option>Primary Button Arrow</option>
				  <option>Primary Button</option>
				  <option>Secondary Button Arrow</option>
				  <option>Secondary Button</option>
				  <option>Outline Light Arrow</option>
				  <option>Outline Light</option>
				  <option>Outline Dark Arrow</option>
				  <option>Outline Dark</option>
				  <option>Anchor Button with Arrow</option>
				  <option>Anchor Button</option>
				</select>
			  </div>
			</div>
		  </div>
		</div>
		<div class="slds-form-element slds-grid slds-gutters">
		  <div class="slds-col">
			<label class="slds-form-element__label">Text Width</label>
			<div class="slds-form-element__control">
			  <div class="slds-select_container">
				<select class="slds-select" id="cta-width" value="${value.ctaWidth}">
				  <option value="" disabled selected>Select…</option>
				  <option>10</option>
				  <option>20</option>
				  <option>30</option>
				  <option>40</option>
				  <option>50</option>
				  <option>60</option>
				  <option>70</option>
				  <option>80</option>
				  <option>90</option>
				  <option>100</option>
				</select>
			  </div>
			</div>
		  </div>
		</div>
		<div class="slds-form-element slds-grid slds-gutters">
		  <div class="slds-col">
			<label class="slds-form-element__label">CTA Label</label>
			<input type="text" id="cta-label" class="slds-input slds-col" value="${value.ctaLabel}" />
			<label class="slds-form-element__label">Heading label</label>
			<textarea type="textArea" id="heading-label" class="slds-input slds-col">${value.headingLabel}</textarea>
			<input type="hidden" id="hidden-input" class="slds-input slds-col" />
		  </div>
		</div>
	  </div>`;

		// show "Loading.. "
		document.body.appendChild(rootEditorElement);
	}

	/** the page designer signals readiness to show this editor and provides an optionally pre selected value */
	listen(
		"sfcc:ready",
		async ({
			value,
			config,
			isDisabled,
			isRequired,
			dataLocale,
			displayLocale,
		}) => {
			const selectedValue =
				typeof value === "object" &&
				value !== null &&
				typeof value.value === "string"
					? value.value
					: null;
			if (selectedValue) {
				init(value.value ? JSON.parse(value.value) : "");
				jsonData = JSON.parse(value.value);
			} else {
				init({
					headingStyle: "Heading 1",
					descriptionStyle: "Paragraph 1",
					ctaStyle: "Primary Button Arrow",
					ctaWidth: "100",
					ctaLabel: "",
					headingLabel: "",
				});
			}

			var jsonElement = rootEditorElement.querySelector("#hidden-input");
			rootEditorElement
				.querySelector("#heading-style")
				.addEventListener("change", function (event) {
					const selectedValue = event.target.value;
					jsonData["headingStyle"] = selectedValue;
					jsonElement.value = JSON.stringify(jsonData);
					jsonElement.dispatchEvent(new Event("change"));
				});
			rootEditorElement
				.querySelector("#description-style")
				.addEventListener("change", function (event) {
					const selectedValue = event.target.value;
					jsonData["descriptionStyle"] = selectedValue;
					jsonElement.value = JSON.stringify(jsonData);
					jsonElement.dispatchEvent(new Event("change"));
				});
			rootEditorElement
				.querySelector("#cta-style")
				.addEventListener("change", function (event) {
					const selectedValue = event.target.value;
					jsonData["ctaStyle"] = selectedValue;
					jsonElement.value = JSON.stringify(jsonData);
					jsonElement.dispatchEvent(new Event("change"));
				});
			rootEditorElement
				.querySelector("#cta-width")
				.addEventListener("change", function (event) {
					const selectedValue = event.target.value;
					jsonData["ctaWidth"] = selectedValue;
					jsonElement.value = JSON.stringify(jsonData);
					jsonElement.dispatchEvent(new Event("change"));
				});
			rootEditorElement
				.querySelector("#cta-label")
				.addEventListener("change", function (event) {
					const selectedValue = event.target.value;
					jsonData["ctaLabel"] = selectedValue;
					jsonElement.value = JSON.stringify(jsonData);
					jsonElement.dispatchEvent(new Event("change"));
				});
			rootEditorElement
				.querySelector("#heading-label")
				.addEventListener("change", function (event) {
					const selectedValue = event.target.value;
					jsonData["headingLabel"] = selectedValue;
					jsonElement.value = JSON.stringify(jsonData);
					jsonElement.dispatchEvent(new Event("change"));
				});

			if (selectedValue) {
				const values = JSON.parse(selectedValue);
				if (values.headingStyle != "") {
					rootEditorElement.querySelector("#heading-style").value =
						values.headingStyle;
					rootEditorElement
						.querySelector("#heading-style")
						.dispatchEvent(new Event("change"));
				}
				if (values.descriptionStyle != "") {
					rootEditorElement.querySelector(
						"#description-style"
					).value = values.descriptionStyle;
					rootEditorElement
						.querySelector("#description-style")
						.dispatchEvent(new Event("change"));
				}
				if (values.ctaStyle != "") {
					rootEditorElement.querySelector("#cta-style").value =
						values.ctaStyle;
					rootEditorElement
						.querySelector("#cta-style")
						.dispatchEvent(new Event("change"));
				}
				if (values.ctaWidth != "") {
					rootEditorElement.querySelector("#cta-width").value =
						values.ctaWidth;
					rootEditorElement
						.querySelector("#cta-width")
						.dispatchEvent(new Event("change"));
				}
			}

			jsonElement.addEventListener("change", function (event) {
				var selectedValue = event.target.value;
				emit({
					type: "sfcc:interacted",
				});
				emit({
					type: "sfcc:value",
					payload: selectedValue ? { value: selectedValue } : null,
				});
			});
		}
	);

	// When a value was selected
	listen("sfcc:value", (value) => {});

	// When the editor must require the user to select something
	listen("sfcc:required", (value) => {});

	// When the editor is asked to disable its controls
	listen("sfcc:disabled", (value) => {});
})();
