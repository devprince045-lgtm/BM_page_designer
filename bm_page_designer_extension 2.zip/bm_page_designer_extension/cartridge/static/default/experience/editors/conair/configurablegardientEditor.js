/**
 * SLDS Configurable Gardient Editor
 */
(() => {

  /** The main Editor element to be tinkered with */
  var rootEditorElement;

  /** Variable that we are using to collect multiple data */
  var jsonData = {};

  /**
   * initializes the base markup before page is ready. This is not part of the API, and called explicitely at the end of this module.
   */
  function init(value) {
    rootEditorElement = document.createElement('div');
    rootEditorElement.innerHTML = `
    <div class="slds-p-around_small">
     <div class="slds-form-element">
      <div class="slds-form-element__control">
        <div class="slds-checkbox">
          <input type="checkbox" name="options" id="gradent-desktop-checkbox" value="" ${value.gradientDesktop ? 'checked' : ''}/>
          <label class="slds-checkbox__label" for="gradent-desktop-checkbox">
            <span class="slds-checkbox_faux"></span>
            <span class="slds-form-element__label">Desktop</span>
          </label>
          <input type="checkbox" name="options" id="gradent-mobile-checkbox" value="" ${value.gradientMobile ? 'checked' : ''} />
          <label class="slds-checkbox__label" for="gradent-mobile-checkbox">
            <span class="slds-checkbox_faux"></span>
            <span class="slds-form-element__label">Tablet/Mobile</span>
          </label>
        </div>
      </div>
    </div>
    <div class="slds-form-element slds-grid slds-gutters">
      <div class="slds-col">
        <label class="slds-form-element__label" for="select-01">Gradient Height</label>
  			<div class="slds-form-element__control">
			    <div class="slds-select_container">
				    <select class="slds-select" id="gradent-height" value="${value.gradientHeight}">
				      <option value="" disabled selected>Select…</option>
				      <option>10</option>
				      <option>20</option>
				      <option>30</option>
				      <option>40</option>
				      <option>50</option>
				      <option>60</option>
				      <option>70</option>
				      <option>80</option>
				      <option>90</option>
				      <option>100</option>
				    </select>
			    </div>
			  </div>
      </div>
      <input type="hidden" id="gradient-hidden" class="slds-input slds-col" value="${JSON.stringify(value)}" />
    </div>
  </div>`;

    // show "Loading.. "
    document.body.appendChild(rootEditorElement);
  };

  /** the page designer signals readiness to show this editor and provides an optionally pre selected value */
  listen('sfcc:ready',async ({ value,config,isDisabled,isRequired,dataLocale,displayLocale }) => {
    const selectedValue = typeof value === 'object' && value !== null && typeof value.value === 'string' ? value.value : null;
    if (selectedValue) {
      init(value.value ? JSON.parse(value.value) : '');
      jsonData = JSON.parse(value.value);
    } else {
      init({ gradientDesktop: '',gradientMobile: '',gradientHeight: '' });
    }
    var jsonElement = rootEditorElement.querySelector('#gradient-hidden');
    rootEditorElement.querySelector('#gradent-desktop-checkbox').addEventListener('change',function (event) {
      const selectedValue = event.target.checked;
      jsonData['gradientDesktop'] = selectedValue;
      jsonElement.value = JSON.stringify(jsonData);
      jsonElement.dispatchEvent(new Event('change'));
    });
    rootEditorElement.querySelector('#gradent-mobile-checkbox').addEventListener('change',function (event) {
      const selectedValue = event.target.checked;
      jsonData['gradientMobile'] = selectedValue;
      jsonElement.value = JSON.stringify(jsonData);
      jsonElement.dispatchEvent(new Event('change'));

    });
    rootEditorElement.querySelector('#gradent-height').addEventListener('change',function (event) {
      const selectedValue = event.target.value;
      jsonData['gradientHeight'] = selectedValue;
      jsonElement.value = JSON.stringify(jsonData);
      jsonElement.dispatchEvent(new Event('change'));

    });

    if (selectedValue) {
      const values = JSON.parse(selectedValue);
      if (values.gradientHeight != "") {
        rootEditorElement.querySelector("#gradent-height").value =
          values.gradientHeight;
        rootEditorElement
          .querySelector("#gradent-height")
          .dispatchEvent(new Event("change"));
      }
    }
    jsonElement.addEventListener('change',function (event) {
      const selectedValue = event.target.value;
      emit({
        type: 'sfcc:interacted'
      });
      emit({
        type: 'sfcc:value',
        payload: selectedValue ? { value: selectedValue } : null
      });

    });

  });

  // When a value was selected
  listen('sfcc:value',value => { });

  // When the editor must require the user to select something
  listen('sfcc:required',value => { });

  // When the editor is asked to disable its controls
  listen('sfcc:disabled',value => { });

})();
