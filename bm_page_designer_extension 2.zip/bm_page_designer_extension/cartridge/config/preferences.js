'use strict';

module.exports = {
    colorsArray: {
        'us-waringcommercialproducts-sfra': [
            '#223755', '#23628C', '#41ADFF', '#471515', '#E80202', '#FFA3A3', '#8F7200',
            '#D1A700', '#296529', '#53BE51', '#000000', '#2B2B2B', '#757575', '#949494',
            '#C5C5C5', '#F0F0F0', '#fff'
        ]
    },
    defaultValue: [
        '#e3abec', '#c2dbf7', '#9fd6ff', '#9de7da', '#9df0c0', '#fff099', '#fed49a',
        '#d073e0', '#86baf3', '#5ebbff', '#44d8be', '#3be282', '#ffe654', '#ffb758',
        '#bd35bd', '#5779c1', '#00a1e0', '#00aea9', '#3cba4c', '#f5bc25', '#f99221',
        '#580d8c', '#001970', '#0a2399', '#0b7477', '#41693d', '#b67e11', '#b85d0d',
        '#FFFFFF', '#DDDDDD', '#BBBBBB', '#999999', '#666666', '#333333', '#000000'
    ]
};

